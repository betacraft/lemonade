The Cascadia package implements CSS selectors for use with the parse trees produced by the html package.
