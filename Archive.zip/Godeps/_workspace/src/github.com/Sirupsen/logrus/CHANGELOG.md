# 0.7.2

formatter/text: Add configuration option for time format (#158)
