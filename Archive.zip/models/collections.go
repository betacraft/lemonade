package models

const (
	C_USERS   = "users"
	C_ADMINS  = "admins"
	C_PRODUCT = "products"
	C_DEAL    = "deals"
	C_GROUP   = "groups"
)
