package controllers

import (
	"github.com/rainingclouds/lemonades/framework"
	"net/http"
)

func CreateDeal(w http.ResponseWriter, r *framework.Request) {

}
