#Lemonade
Our take on e-commerce. For now its gonna be more of a coding task than readme task ;).